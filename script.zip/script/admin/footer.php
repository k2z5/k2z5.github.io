</div>
</div>
<div class="footer">
Powered By <b>RSS-Script Light Version</b>
</div>
</div>
</body>
</html>