<?php
$db_config = array(
	'host' => 'localhost',
	'user' => 'your_database_username',
	'pass' => 'your_database_password',
	'name' => 'your_database_name'
);
?>
