var language_direction = 'rtl';
var voted_before = 'لقد قمت بالتصويت مسبقاً';
var error_happened = 'حصل خطأ';
