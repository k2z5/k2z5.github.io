var language_direction = 'ltr';
var voted_before = 'You Have voted Before.';
var error_happened = 'Error Happened';
