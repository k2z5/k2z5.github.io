<?php
require_once "initd.php";

$objTheme->define(Array("MAIN_CONTENT" => "index.tpl"));
$objTheme->templatePrint();
?> 
