<?php

function getString($string, $len = 30) {
	if (strlen($string) > $len) {
		$string = substr($string, 0, $len - 1) . "...";
	}
	return $string;
}
?>
