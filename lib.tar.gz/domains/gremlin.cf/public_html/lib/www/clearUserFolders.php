<?php
function cleanFolder($path) {
	$arrDirs = scandir($path);
	$fileCount = 0;
	$dirCount = 0;
	if (is_array($arrDirs)) {
		foreach ($arrDirs as $key => $val) {
			if (is_dir($path  . $val) && $val != "." && $val != "..") {
				$dirCount++;
				$arrFiles = scandir($path  . $val);
				if (is_array($arrFiles)) {
					foreach ($arrFiles as $key2 => $val2) {
						if (is_file($path  . $val . "/" . $val2)) {
							$fileCount++;
							unlink($path  . $val . "/" . $val2);
						}
					}
				}
				rmdir($path . $val);
			}
		}
	}
	echo("<br><b>".$path."</b><br>Folder(s) deleted: " . $dirCount . " File(s) deleted: " . $fileCount);
}

require_once "initd.php";
$objDB -> select("TRUNCATE TABLE tiffImageList;");
cleanFolder(USER_IMAGE_STORAGE);
cleanFolder(FILES_SIMLINK_STORAGE);
?>