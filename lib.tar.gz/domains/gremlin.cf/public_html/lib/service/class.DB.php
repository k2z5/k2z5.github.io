<?php

class DB {
	private $dblocation = "localhost";
	private $dbname = "";
	private $dbuser = "";
	private $dbpass = "";
	//private $dbpass = "";
	private $error;
	private $dbcnx;

	public function __construct() {
		$this -> dbcnx = @mysql_connect($this -> dblocation, $this -> dbuser, $this -> dbpass);
		if (!$this -> dbcnx) {
			$this -> error = mysql_error();
			throw new Exception($this -> error);
		}
		if (!@mysql_select_db($this -> dbname, $this -> dbcnx)) {
			$this -> error = mysql_error();
			throw new Exception($this -> error);
		}
		mysql_query("SET CHARACTER SET utf8;");
	}

	public function getError() {
		return $this -> error;
	}

	public function select($sql) {
		$query = @mysql_query($sql, $this -> dbcnx);
		if (!is_resource($query)) {
			$this -> error = mysql_error();
			return false;
		}
		$arrReturn = array();
		while ($data = mysql_fetch_assoc($query)) {
			$arrReturn[] = $data;
		}
		return $arrReturn;

	}

	public function insert($table, $arrFieldValues) {
		$fields = array_keys($arrFieldValues);
		$values = array_values($arrFieldValues);

		$escValues = array();
		foreach ($values as $val) {
			if (!is_numeric($val) && $val != "NOW()" && substr($val, 0, 7) != "ADDDATE") {
				$val = "'" . $val . "'";
				//echo($val."<br>");
			}
			$escValues[] = $val;
		}

		$sql = "INSERT INTO " . $table . " (";
		$sql = $sql . join(", ", $fields);
		$sql = $sql . ") VALUES (";
		$sql = $sql . join(", ", $escValues) . ");";
		$query = mysql_query($sql);
		if (!$query) {
			$this -> error = mysql_error();
			return false;
		} else {
			return true;
		}
	}

	public function delete($table, $arrConditions) {
		$arrWhere = array();
		$counter = 0;
		foreach ($arrConditions as $field => $val) {
			$counter++;
			if (!is_numeric($val)) {
				$val = "'" . $val . "'";
			}
			if ($counter == count($arrConditions)) {
				@$sql = $sql . $field . " = " . $val . ";";
			} else {
				@$sql = $sql . $field . " = " . $val . " AND ";
			}

		}

		$sql = "DELETE FROM " . $table . " WHERE " . $sql;
		$query = mysql_query($sql);
		if ($query) {
			return true;
		} else {
			$this -> error = mysql_error();
			return false;
		}
	}

	public function deletefull($table) {
		$sql = "DELETE FROM " . $table . ";";
		$query = mysql_query($sql);
		if (!is_resource($query)) {
			$this -> error = mysql_error();
			return false;
		}
		return true;
	}

	public function update($table, $arrFieldValues, $arrConditions) {
		$arrUpdate = array();
		foreach ($arrFieldValues as $field => $val) {
			if (!is_numeric($val) && $val != "NOW()" && substr($val, 0, 7) != "ADDDATE") {
				$val = "'" . $val . "'";
			}
			$arrUpdate[] = $field . " = " . $val;
		}

		$arrWhere = array();
		foreach ($arrConditions as $field => $val) {
			if (!is_numeric($val) && $val != "NOW()") {
				$val = "'" . $val . "'";
			}
			$arrWhere[] = $field . " = " . $val;
		}

		$sql = "UPDATE " . $table . " SET " . join(", ", $arrUpdate) . " WHERE " . join(" AND ", $arrWhere);
		$query = mysql_query($sql);

		if (!$query) {
			$this -> error = mysql_error();
			return false;
		} else {
			return true;
		}
	}

	public function __destruct() {
		if ($this -> dbcnx) {
			@mysql_close($this -> dbcnx);
		}
	}

}
