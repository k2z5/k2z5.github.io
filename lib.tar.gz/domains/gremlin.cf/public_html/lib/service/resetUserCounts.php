<?php
require_once "class.DB.php";

$objDB = new DB();

$objDB -> select("UPDATE userOptions SET value=0 WHERE name LIKE 'CurrentCount%';");
echo("Счетчики пользователей сброшены успешно.");
?>
