<?php if (@$content['nothing']) { ?>
<p id="e2-nothing-message"><?=@$content['nothing']?></p>
<?php } ?>
