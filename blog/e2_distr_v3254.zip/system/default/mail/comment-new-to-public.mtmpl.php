<?= $content['comment-text'] ?> 
	<?= $content['commenter'] ?> 

<?= $content['comment-href'] ?> 


<?= _S ('em--unsubscribe') ?>:
<?= $content['unsubscribe-href'] ?> 


<?= _S ('em--created-automatically') ?>