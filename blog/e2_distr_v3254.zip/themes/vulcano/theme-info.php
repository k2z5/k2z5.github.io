<?php return array (

  'index' => 55,
  
  'display_name' => array (
    'en' => 'Vulcano',
    'ru' => 'Вулькано',
  ),

  'colors' => array (
    'background' => '#272637',#151c2c
    'headings' => '#c6343f',
    'text' => '#d4baa5',
    'link' => '#F9C4AC',
    // http://colorhunt.co/c/78984
  ),

  'based_on' => 'plain',
  'meta_viewport' => 'width=device-width, initial-scale=1',
  'use_likely_light' => true,

); ?>