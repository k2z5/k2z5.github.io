<?php return array (

  'index' => 59,

  'display_name' => array (
    'en' => 'Holm',
    'ru' => 'Холм',
  ),

  'colors' => array (
    'background' => '#242322',
    'headings' => '#fff',
    'text' => '#898887',
    'link' => '#f06a21',
  ),

  'based_on' => 'plain',
  'meta_viewport' => 'width=device-width, initial-scale=1',
  'use_likely_light' => true,

); ?>