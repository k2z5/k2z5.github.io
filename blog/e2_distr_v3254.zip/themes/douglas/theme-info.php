<?php return array (

  'index' => 51,
  
  'display_name' => array (
    'en' => 'Douglas',
    'ru' => 'Дуглас',
  ),

  'colors' => array (
    'background' => '#3a4149',
    'headings' => '#ff5d57',
    'text' => '#fff',
    'link' => '#70a0b0',
  ),

  'based_on' => 'plain',
  'meta_viewport' => 'width=device-width, initial-scale=1',
  'use_likely_light' => true,

); ?>