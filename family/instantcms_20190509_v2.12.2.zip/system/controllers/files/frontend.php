<?php
class files extends cmsFrontend {}
