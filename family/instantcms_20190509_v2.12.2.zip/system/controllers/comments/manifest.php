<?php

    return array(

        'hooks' => array(
            'ctype_basic_form',
            'photos_before_item',
            'content_item_form',
            'content_before_item',
            'content_before_list',
            'content_after_update',
            'admin_dashboard_chart',
            'user_privacy_types',
            'user_login',
            'user_notify_types',
            'user_delete',
            'user_tab_info',
            'user_tab_show',
            'moderation_list'
        )

    );
