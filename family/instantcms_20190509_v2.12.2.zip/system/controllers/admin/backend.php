<?php

class backendAdmin extends cmsBackend{

}
