<?php

    return array(

        'hooks' => array(
            'menu_admin',
            'admin_dashboard_block',
            'user_login',
            'admin_confirm_login',
            'grid_admin_content_items_args'
        )

    );
