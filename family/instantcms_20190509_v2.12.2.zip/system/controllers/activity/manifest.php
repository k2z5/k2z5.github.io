<?php

    return array(

        'hooks' => array(
            'content_after_add_approve',
            'admin_dashboard_block',
            'content_after_update_approve',
            'publish_delayed_content',
            'user_delete',
            'user_tab_info',
            'subscribe',
            'unsubscribe',
            'user_tab_show'
        )

    );
