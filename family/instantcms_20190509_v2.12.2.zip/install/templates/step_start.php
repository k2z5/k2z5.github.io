<h1><?php echo LANG_STEP_START; ?></h1>

<div class="image">
    <img src="images/install.png" />
</div>

<p><?php echo LANG_STEP_START_1; ?></p>

<p><?php echo LANG_STEP_START_2; ?></p>

<p><?php echo LANG_STEP_START_3; ?></p>

<p>
    <?php echo LANG_MANUAL; ?>
</p>

<div class="buttons">
    <input type="button" name="next" id="btn-next" value="<?php echo LANG_NEXT; ?>" onclick="nextStep()" />
</div>