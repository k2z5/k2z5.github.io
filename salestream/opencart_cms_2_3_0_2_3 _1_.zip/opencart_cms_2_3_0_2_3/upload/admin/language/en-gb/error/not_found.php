<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']  = 'Page Not Found!';

// Text
$_['text_not_found'] = 'The page you are looking for could not be found! Please contact your administrator if the problem persists.';