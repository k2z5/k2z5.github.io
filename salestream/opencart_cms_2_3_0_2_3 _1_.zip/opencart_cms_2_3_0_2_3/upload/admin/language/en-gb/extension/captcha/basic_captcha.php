<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

$_['heading_title']    = 'Basic Captcha';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Basic Captcha!';
$_['text_edit']        = 'Edit Basic Captcha';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Basic Captcha!';
