<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']	 = 'OpenBay Pro';

// Text
$_['text_module']    = 'Modules';
$_['text_installed'] = 'OpenBay Pro module is now installed. It is available under Extensions -> OpenBay Pro';